package com.example.calculadora1;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView TvResultado;
    EditText EtNumero1, EtNumero2;
    Button BtnSumar, BtnRestar, BtnMultiplicacion, BtnDividir;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TvResultado = findViewById(R.id.tv_resultado);
        EtNumero1 = findViewById(R.id.et_numero1);
        EtNumero2 = findViewById(R.id.et_numero2);
        BtnSumar = findViewById(R.id.btn_suma);
        BtnRestar = findViewById(R.id.btn_restar);
        BtnMultiplicacion = findViewById(R.id.btn_multiplicacion);
        BtnDividir = findViewById(R.id.btn_dividir);
    }
}